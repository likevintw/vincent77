#include "./inc/embeddedproxy.h"
#include <stdio.h>
#include <unistd.h>

using namespace monitor; 

int main(int argc, const char *argv[])
{
	printf("1\n");
	CEmbeddedProxy *test = new CEmbeddedProxy();
	printf("2\n");
	test->initialize(argv[1]);
	printf("3\n");
	printf("4\n");
	test->uninitialize();
	printf("5\n");

	return 0;
}

