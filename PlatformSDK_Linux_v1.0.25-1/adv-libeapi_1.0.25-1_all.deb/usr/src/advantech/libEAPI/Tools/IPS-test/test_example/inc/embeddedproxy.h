/*
 * embeddedproxy.h
 *
 *  Created on: Jul 3, 2018
 *      Author: diron
 */

#ifndef inc_embeddedproxy_h_2a3baa82
#define inc_embeddedproxy_h_2a3baa82

#include "atIPSAE.h"
#include <boost/make_shared.hpp>
namespace monitor
{
	using namespace EApiCommon;
	class AdvIPSAEWorker : public IatCallBack {
		virtual void atCallBack(CallBackType type, string str);
	};

	class CEmbeddedProxy {
		public:
			CEmbeddedProxy();
			~CEmbeddedProxy();

			bool initialize(const char *comport);
			void uninitialize();

			//        bool is_connected();
			//        bool set_DCoutCutOffDelayTime(int time_min);
			//        bool set_DCinLostDelayTime(int time_s);

		protected:
			typedef EApiStatus_t (*funcEApiUPSGetDevice)(EApiCommon::IatIPSAE **, string, EApiCommon::IatCallBack *);
			typedef EApiStatus_t (*funcEApiUPSDelDevice)();

			enum IPSState{
				DCIN,
				DCINLost,
				CutOff,
			};

			bool get_iatipsae(const char* szport, EApiCommon::IatIPSAE** lpipsae, EApiCommon::IatCallBack *worker);


		public:
			void* pdll_ = NULL;
			boost::shared_ptr<AdvIPSAEWorker> worker_;
	};
}



#endif /* inc_embeddedproxy_h_2a3baa82 */
