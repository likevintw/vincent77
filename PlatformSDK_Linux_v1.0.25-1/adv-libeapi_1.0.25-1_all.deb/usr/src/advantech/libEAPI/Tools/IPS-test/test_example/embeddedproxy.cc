/*
 * embeddedproxy.cc
 *
 *  Created on: Jul 3, 2018
 *      Author: diron
 */
#include <dlfcn.h>
#include <stdio.h>
#include <unistd.h>
#include "inc/embeddedproxy.h"

namespace monitor
{
	void AdvIPSAEWorker::atCallBack(EApiCommon::CallBackType type, string str){
		switch(type){
			case EApiCommon::EMERGENCY:{
							   printf("dc in losted power");
							   printf("DC-Out Cut-Off trigger");
						   }break;
			case EApiCommon::INFOMATION:
						   break;
			default:
						   break;
		}
	}

	CEmbeddedProxy::CEmbeddedProxy() {

	}

	CEmbeddedProxy::~CEmbeddedProxy(){

	}

	bool CEmbeddedProxy::initialize(const char *comport){
		if(worker_ == NULL){
			worker_.reset(new AdvIPSAEWorker());
			if(worker_ == NULL){
				printf("create ips callback fail.");
				return false;
			}
		}

		if(pdll_ == NULL){
			printf("port: %s\n", comport);
			pdll_ = dlopen("libEAPI-IPS.so", RTLD_LAZY);
			if(pdll_ == NULL){
				printf("failed load library.");
				return false;
			}

			funcEApiUPSGetDevice EApiUPSGetDevice;
			EApiUPSGetDevice = (funcEApiUPSGetDevice)dlsym(pdll_, "EApiUPSGetDevice");
			if(EApiUPSGetDevice == NULL){
				printf("failed load symbol EApiUPSGetDevice.");
				return false;
			}

			IatIPSAE *patIPSAE = NULL;
			int ret = EApiUPSGetDevice(&patIPSAE, comport, (IatCallBack*)worker_.get());
			if(ret != 0 || patIPSAE == NULL){
				printf("open serial com:%s fail.", comport);
				return false;
			}

			int cutoff = 5;
			int inlost = 300;

			printf("Sleep 5s\n");sleep(5);
			printf("Sleep 5s\n");sleep(5);

			if(cutoff > 0){
				std::string strv = patIPSAE->setDCoutCutOffDelayTime(cutoff);
				printf("set dcout cut off delay ret:%s\n", strv.c_str());
			}

			if(inlost > 0){
				string strv = patIPSAE->setDCinLostDelayTime(inlost);
				printf("set dcin loast delay ret:%s\n", strv.c_str());
			}
		}
		return true;
	}

	void CEmbeddedProxy::uninitialize(){
		if(pdll_ != NULL){
			funcEApiUPSDelDevice EApiUPSDelDevice;
			EApiUPSDelDevice = (funcEApiUPSDelDevice)dlsym(pdll_, "EApiUPSDelDevice");
			if (EApiUPSDelDevice!=NULL) {
				EApiUPSDelDevice();
			} else {
				printf("Failed load symbol EApiUPSDelDevice");
			}
			dlclose(pdll_);
			pdll_ = NULL;
		}

		if(worker_ != NULL){
			worker_.reset();
		}
	}
}
